#Carmen Mendoza 
#Module 8.2 




import json

# Function to print student list
def print_students(student_list, message):
    print(message)
    for student in student_list:
        print(f"{student['F_Name']} , {student['L_Name']} : ID = {student['Student_ID']} , Email = {student['Email']}")
    print()

# Load data from JSON file
with open('C:/Users/cmend/Desktop/JSON Files/students.json', 'r') as file:

    students = json.load(file)

# Print the original student list
print_students(students, "Original Student List:")

# Add a new student
new_student = {
    "F_Name": "Carmen",
    "L_Name": "Mendoza",
    "Student_ID": 21399968,
    "Email": "camendoza@my365.bellevue.edu"
}
students.append(new_student)

# Print the updated student list
print_students(students, "Updated Student List:")

# Save the updated list to the JSON file
with open('students.json', 'w') as file:
    json.dump(students, file, indent=4)

print("The students.json file has been updated.")
