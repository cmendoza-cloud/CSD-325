# Carmen Mendoza
# Module 9.2 
# Dog API 

# Create a API of your choice 

import requests

# API endpoint
url = "https://api.thedogapi.com/v1/breeds"

# Make the API request
response = requests.get(url)

# Check if the connection is correct
if response.status_code == 200:
    data = response.json()  # Convert response to JSON

    # Filter for Australian Cattle Dog
    cattle_dog = next((breed for breed in data if "Australian Cattle Dog" in breed['name']), None)

    # Print results
    if cattle_dog:
        print("Raw Response:")
        print(cattle_dog)  # Unformatted output

        # Formatted output
        print("\nFormatted Output:")
        print(f"Breed: {cattle_dog['name']}")
        print(f"Breed Group: {cattle_dog.get('breed_group', 'N/A')}")
        print(f"Life Span: {cattle_dog['life_span']}")
        print(f"Temperament: {cattle_dog['temperament']}")
        
        
    else:
        print("Australian Cattle Dog not found.")
else:
    print("Failed to connect to API. Status code:", response.status_code)
