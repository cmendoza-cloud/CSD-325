# Carmen Mendoza
# Module 9.2 

import requests
import json

# Make a GET request to the API URL
response = requests.get("http://api.open-notify.org/astros.json")

# Get the JSON response
data = response.json()

# Check if the response contains the expected data
if data['message'] == 'success':
    # Print the entire response in JSON format
    print(json.dumps(data, indent=4))  # Format with indentation for readability
else:
    print("Failed to retrieve astronaut data.")




